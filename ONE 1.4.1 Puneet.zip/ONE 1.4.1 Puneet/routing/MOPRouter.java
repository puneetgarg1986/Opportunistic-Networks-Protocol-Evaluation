/*
 * 
 * University of S�o Paulo
 * 
 * jteodoro at ime.usp.br
 * thiagofurtado17 at gmail.com
 * 
 */
package routing;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import routing.fresh.LastEncounter;
import routing.mop.MemoryNeighbor;
import core.Connection;
import core.Coord;
import core.DTNHost;
import core.Message;
import core.Settings;

/**
 * Implementation of FRESH router as described in 
 * <I>Age Matters: Efficient Route Discovery in Mobile Ad Hoc Networks 
 * Using Encounter Ages</I> by
 * Henri DuboisFerriere, Matthias Grossglauser and Martin Vetterli
 * 
 */
public class MOPRouter extends ActiveRouter {
	
	private List<MemoryNeighbor> lastNeighbors;
	public static final String MAX_NEIGHBOR_MEMORY = "sizeOfMemoriesTable";
	public static int maxEncounters = 100;
	
	/**
	 * Constructor. Creates a new message router based on the settings in
	 * the given Settings object.
	 * @param s The settings object
	 */
	public MOPRouter(Settings s) {
		super(s);
		maxEncounters = s.getInt(MAX_NEIGHBOR_MEMORY);
		lastNeighbors = new LinkedList<MemoryNeighbor>();
	}

	/**
	 * Copy constructor.
	 * @param r The router prototype where setting values are copied from
	 */
	protected MOPRouter(MOPRouter r) {
		super(r);
		//be careful with deepcopy
		this.lastNeighbors = new LinkedList<MemoryNeighbor>();
	}

	@Override
	public void changedConnection(Connection con) {
		if (con.isUp()) {
			
			DTNHost otherHost = con.getOtherNode(getHost());
			updateNeighborTable(otherHost, this.lastNeighbors );
			
		}
		
	}
	
	//update neighbor table and verify the table size
	private void updateNeighborTable(DTNHost otherHost, List<MemoryNeighbor> neighborTable) {
		
		Date date = new Date();
		MemoryNeighbor neighbor = null;
		if ( this.lastNeighbors.contains(otherHost.getAddress()) ) {
			int pos = this.lastNeighbors.indexOf(otherHost.getAddress());
			neighbor = this.lastNeighbors.get( pos );
			//remove from current position
			this.lastNeighbors.remove(pos);
			//update position and time
			neighbor.coord = otherHost.getLocation();
			neighbor.time = date.getTime();
		}
		else {
			neighbor = new MemoryNeighbor(otherHost.getAddress(), date.getTime() , otherHost.getLocation());
		}
		
		//inserts at end of row
		this.lastNeighbors.add(neighbor);
		//remove the oldest element if the queue is longer than it should
		if ( this.lastNeighbors.size() > maxEncounters ) {
			this.lastNeighbors.remove(0);
		}
		
	}

	@Override
	public void update() {
		super.update();
		if (!canStartTransfer() ||isTransferring()) {
			return; // nothing to transfer or is currently transferring 
		}
		
		// try messages that could be delivered to final recipient
		if (exchangeDeliverableMessages() != null) {
			return;
		}
		
		//send messages to current neighbors
		checkTimeAndPosition(this.getConnections(), new ArrayList<Message>(this.getMessageCollection()) );
		
	}
	
	private void checkTimeAndPosition(List<Connection> currentConnections, List<Message> currentMessages) {
		
		//for each message check the values and send the flood
		for ( Message m : currentMessages ) {
			
			//if no one knows destination node
			if ( m.memoryTime == -1 && m.hopsToSearch > 0 && m.floodAgain ) {
				//if I do broadCast I should set the flag so it doesn't send again
				m.hopsToSearch--;
				m.floodAgain = false;
				sendMessageToConnections(currentConnections, m);
				return;
			}
			
			if ( this.lastNeighbors.contains( m.getTo().getAddress() ) ) {
				//if i know destination node
				int position = this.lastNeighbors.indexOf(m.getTo().getAddress());
				MemoryNeighbor neihbor = this.lastNeighbors.get(position);
				
				//my time is shorter
				if ( m.memoryTime > neihbor.time ) {
					m.lastHopCoord = this.getHost().getLocation();
					m.memoryTime = neihbor.time;
					m.destinationCoord = neihbor.coord;
					sendMessageToConnections(currentConnections, m);
					return;
				}
				
			}
			//my position is closer to the destination even though I don't know
			//or my time is longer
			if ( m.memoryTime > 0 && m.destinationCoord.distance(this.getHost().getLocation()) > m.destinationCoord.distance(m.lastHopCoord) ) {
				m.lastHopCoord = this.getHost().getLocation();
				sendMessageToConnections(currentConnections, m);
				return;
			}
			
		}
		
	}
	
	private void sendMessageToConnections(List<Connection> currentConnections, Message currentMessage) {
		
		for (Connection c : currentConnections ) {
			this.startTransfer(currentMessage, c);
		}
		
	}

	
	@Override
	public MessageRouter replicate() {
		MOPRouter r = new MOPRouter(this);
		return r;
	}

}
